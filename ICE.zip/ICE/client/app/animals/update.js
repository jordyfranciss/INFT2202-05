/*
    Name:   Jordy Francis
    filename: app.js
    Course: INFT 2202
    Date: January 10
    Description: This is my general application script.  Functions that are required on every page should live here.
*/